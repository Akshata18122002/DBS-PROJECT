package CustomWidgets;

import javax.swing.JPanel;

public class TransparentJPanel extends JPanel {
    public TransparentJPanel() {
        setOpaque(false);
    }
}
